package com.model;

public class Addition {
	int a,b;
	
	public Addition()
	{
		a = b =0;
	}
	
	public Addition(int x)
	{
		a = b = x;
	}
	
	public Addition(int x, int y)
	{
		a = x;
		b = y;
	}
	
	public int add()
	{
		return a+b;
	}
	
	public int add(int x)
	{
		a = b = x;
		return a+b;
	}
	
	public int add(int x , int y)
	{
		return x+y;
	}
	
	public int add(int x , int y, int z)
	{
		return x+y+z;
	}
}
