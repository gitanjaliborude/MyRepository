package com.model;

public class Multiplication {

}
