package com.operations;

import com.model.Addition;

public class Operations {
	String op;
	
	public Operations()
	{
		op = "add";
	}
	
	public Operations(String op)
	{
		this.op = op;
		operationCall(op);
	}
	
	public void operationCall(String op)
	{
		if(op.equals("add"))
			add();
		if(op.equals("sub"))
			sub();
		if(op.equals("mul"))
			mul();
		if(op.equals("div"))
			div();
	}
	
	public void add()
	{
		Addition a = new Addition();
		System.out.println("Addition : "+a.add(10, 20, 30));
	}
	
	public void sub()
	{
		
	}
	
	public void mul()
	{
		
	}
	public void div()
	{
		
	}
}
