package com.demo;

import java.util.Scanner;

import com.operations.Operations;

public class Demo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Operations : add, sub, mul or div");
		System.out.println("enter the operation : ");
		String op = sc.next();
		
		new Operations(op);
		
		sc.close();

	}

}
